c = int(input())
d = int(input())
print("yes" if c <= d else "no")