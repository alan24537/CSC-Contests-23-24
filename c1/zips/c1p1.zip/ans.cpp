#include <bits/stdc++.h>
using namespace std;

int c, d;

signed main() {
    ios_base::sync_with_stdio(0);cin.tie(0);

    cin >> c >> d;
    cout << (c <= d ? "yes" : "no");

    return 0;
}