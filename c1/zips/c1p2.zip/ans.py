n = int(input())
x = int(input())

print(x // n)