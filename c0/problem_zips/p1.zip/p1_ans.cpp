#include <bits/stdc++.h>
using namespace std;

int n, m, o, c;

int main() {
    cin >> n >> m >> o >> c;
    cout << (n * o) + (m * c);
}